import socket
import os
from threading import Thread
import parser as parser
import random
import struct
import time

bear_quest = False

class Proxy2Server(Thread):

    def __init__(self, host, port):
        super(Proxy2Server, self).__init__()
        self.game = None # game client socket not known yet
        self.port = port
        self.host = host
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.connect((host, port))

    # run in thread
    def run(self):
        while True:
            data = self.server.recv(4096)
            if data:
                #print "[{}] <- {}".format(self.port, data[:100].encode('hex'))
                try:         
                    parser.parse(data, self.port, 'server')
                    if len(parser.CLIENT_QUEUE) > 0:
                        pkt = parser.CLIENT_QUEUE.pop()
                        #print "got queue client: {}".format(pkt.encode('hex'))
                        self.game.sendall(pkt)
                except Exception as e:
                    print 'server[{}]'.format(self.port), e
                # forward to client
                self.game.sendall(data)

class Game2Proxy(Thread):

    def __init__(self, host, port):
        super(Game2Proxy, self).__init__()
        self.server = None # real server socket not known yet
        self.port = port
        self.host = host
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((host, port))
        sock.listen(1)
        # waiting for a connection
        self.game, addr = sock.accept()

    def run(self):
        while True:
            data = self.game.recv(4096)
            if data:
        	#print "[{}] -> {}".format(self.port, data[:100].encode('hex'))
	        try:
	            parser.parse(data, self.port, 'client')
	            if len(parser.SERVER_QUEUE) > 0:
	                pkt = parser.SERVER_QUEUE.pop()
	                #print "got queue server: {}".format(pkt.encode('hex'))
	                self.server.sendall(pkt)
	        except Exception as e:
	            print 'client[{}]'.format(self.port), e
	        # forward to server
		if not (bear_quest and data[:2].encode('hex') == "6d76"):
	        	self.server.sendall(data)
		#else:
			#print "bear quest"

class Proxy(Thread):

    def __init__(self, from_host, to_host, port):
        super(Proxy, self).__init__()
        self.from_host = from_host
        self.to_host = to_host
        self.port = port
        self.running = False

    def run(self):
        while True:
            print "[proxy({})] setting up".format(self.port)
            self.g2p = Game2Proxy(self.from_host, self.port) # waiting for a client
            self.p2s = Proxy2Server(self.to_host, self.port)
            print "[proxy({})] connection established".format(self.port)
            self.g2p.server = self.p2s.server
            self.p2s.game = self.g2p.game
            self.running = True

            self.g2p.start()
            self.p2s.start()

# Replace with server address
master_server = Proxy('0.0.0.0', 'x.x.x.x', 3333)
master_server.start()

game_servers = []
for port in range(3000, 3006):
    # Replace with server address
    _game_server = Proxy('0.0.0.0', 'x.x.x.x', port)
    _game_server.start()
    game_servers.append(_game_server)


while True:
    try:
	# Bear quest location: -7903.15 | 64057.43 | 2646.07
	# Full hex data: 33f9f6c56d397a4733612545d1f78d3a00000000
        cmd = raw_input('PwnProxy$ ')  
	if cmd[:4] == 'quit' or cmd[:4] == 'exit':
            os._exit(0)
	elif cmd[:4] == 'bear':
	    bear_quest = True
	    timeout = time.time() + 60*5 # 5min timer
            #cmd = '6d7637f053c60bb20f474149ae44c2059edc00000000'
	    cmd = '6d76ae91e2c5214e7c4714362845d1f78d3a00000000'
	    #[X] Below 33f9f6c56e397a471f211945
	    #[X] Above 33f9f6c56e397a471ff17945
	    #[V] Tree  ae91e2c5214e7c4714362845
	    while True:
		#print cmd
    	        if time.time() > timeout:
                    bear_quest = False
                    break
                for server in game_servers:
                    if server.running:
                        parser.SERVER_QUEUE.append(cmd.decode('hex'))
		time.sleep(.010)
	elif cmd[:3] == 'egg':
	    """
	    11 - GoldenEgg1 -25045.00 18085.00 260.00
	    12 - GoldenEgg2 -51570.00 -61215.00 5020.00
	    13 - GoldenEgg3 24512.00 69682.00 2659.00
	    14 - GoldenEgg4 60453.00 -17409.00 2939.00
	    15 - GoldenEgg5 1522.00 14966.00 7022.00
	    16 - GoldenEgg6 11604.00 -13131.00 411.00
	    17 - GoldenEgg7 -72667.00 -53567.00 1645.00
	    18 - GoldenEgg8 48404.00 28117.00 704.00
	    19 - GoldenEgg9 65225.00 -5740.00 4928.00
	    20 - BallmerPeakEgg -2778.00 -11035.00 10504.00
	    """
            eggs = ["6d76" + struct.pack("fff", -25045.00, 18085.00, 260.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 11)).encode('hex'),
		    "6d76" + struct.pack("fff", -51570.00, -61215.00, 5020.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 12)).encode('hex'),
                    "6d76" + struct.pack("fff", 24512.00, 69682.00, 2659.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 13)).encode('hex'),
                    "6d76" + struct.pack("fff", 60453.00, -17409.00, 2939.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 14)).encode('hex'),
		    "6d76" + struct.pack("fff", 1522.00, 14966.00, 7022.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 15)).encode('hex'),
                    "6d76" + struct.pack("fff", 11604.00, -13131.00, 411.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 16)).encode('hex'),
                    "6d76" + struct.pack("fff", -72667.00, -53567.00, 1645.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 17)).encode('hex'),
		    "6d76" + struct.pack("fff", 48404.00, 28117.00, 704.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 18)).encode('hex'),
                    "6d76" + struct.pack("fff", 65225.00, -5740.00, 4928.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 19)).encode('hex'),
                    "6d76" + struct.pack("fff", -2778.00, -11035.00, 10504.00).encode('hex') + "d1f78d3a00000000" + ("ee"+struct.pack("I", 20)).encode('hex')]
	    for egg in eggs:
	        parser.SERVER_QUEUE.append(egg.decode('hex'))
		time.sleep(5)
        elif cmd[0:7] == 'Server ':
            # send to server
            for server in game_servers:
                if server.running:
                    parser.SERVER_QUEUE.append(cmd[7:].decode('hex'))
        elif cmd[0:7] == 'Client ':
            # send to client
            for server in game_servers:
                if server.running:
                    parser.CLIENT_QUEUE.append(cmd[7:].decode('hex'))
        else:
            reload(parser)
    except Exception as e:
        print e

